package com.springmvc.springmvcapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringmvcAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
