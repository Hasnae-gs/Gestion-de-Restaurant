@extends('layouts.auth')
@section('content')
<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0">

    <!-- Site Metas -->
    <title>Food Funday Restaurant - One page HTML Responsive</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- color -->
    <link id="changeable-colors" rel="stylesheet" href="css/colors/orange.css" />

    <!-- Modernizer -->
    <script src="js/modernizer.js"></script>


    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>


<body>
     
<div id="loader">
        <div id="status"></div>
    </div>
    <div id="site-header">
        
                            <div id="navbar" class="navbar-collapse collapse">
                                <ul class="nav navbar-nav navbar-right">   
                                  <li> <a  href="mes_commmandes">
                                        <img src="images/images.png" alt="">
                                    </a>          </li>                      
                                    <li><a href=href="{{ route('logout') }}"
               onclick="event.preventDefault();
                             document.getElementById('logout-form').submit();">
                {{ __('se deconnecter') }}
            </a></li>

            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                @csrf
            </form></li>
</ul>
                          
        <!-- end header -->
    </div>

<br><br><br>

<section class="ftco-section bg-light">
   <div class="container">
   <div class="row">
      <div class="col-md-12 col-lg-8 mb-5">
        
         <div class="s010">
            <form method="get" action="{{route('client')}}">
               <div class="inner-form">
                  <div class="advance-search">
                     <div class="row">
                        <div class="input-field">
                           <div class="input-select">
                              <select type="text" name="search" placeholder="type_plat">
                                   <option value="">type de plat</option>
                                   <option value="Entrées">Entrées</option>
                                   <option value="Plats principaux">Plats principaux</option>
                                   <option value="À-côtés">À-côtés</option>
                                   <option value="Desserts">Desserts</option>
                                   <option value="Soupes">Soupes </option>
                                   <option value="Sandwichs">Sandwichs</option>
                                   <option value="Boissons">Boissons et cocktails</option>
                                  </select> 
                           </div>
                         <div class="input-field">
                              <button type="submit" class="btn-search"><span ></span>chercher</button>
                           </div>
                        <div class="row third">
                          
                        </div>
                     </div>
                  </div>
               </div>
            </form>
         </div>

  

       
               @foreach($data as $ac)
                                    <div class="offer-item">
                                        <img src="img/{{$ac->image}}" >
                                        <div>
                                            <h3>{{ $ac->intitule }}</h3>
                                            <p>
                                               {{ $ac->description }}
                                            </p>
                                        </div>
                                       {{ $ac->n_calories }}kcal
                                        <span class="offer-price">{{ $ac->prix }}DH</span>
                                    </div>

                                     <a class="btn btn-danger" href="{{route('commmander',['idd'=>$ac->id])}}">commmander</a></th>


               
                  @endforeach
            </tbody>
         </table>


         </div>

 

      
   </div>
</div>
</section>


    <script src="js/all.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/custom.js"></script>
</body>

</html>





                                  
                         
@endsection