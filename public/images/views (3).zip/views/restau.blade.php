@extends('template')

@section('content')
       



<div class="content">
  
    <div class="col-md-12">
      <div class="card">
        <div class="card-header card-header-primary">
          <h4 class="card-title text-light ">Bienvenue dans l'espace Administrateur du restaurant VEGG'UP.  </h4>
          <p class="card-category"></p>
        </div>
      </div>
    </div>
</div>




                                  
                         
@endsection